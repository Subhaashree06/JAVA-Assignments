public class ThreadExperiments {
    public static void main(String[] args) throws InterruptedException {
        Thread high = new Thread(() -> work("HIGH"));
        Thread low = new Thread(() -> work("LOW"));
        high.setPriority(Thread.MAX_PRIORITY);
        low.setPriority(Thread.MIN_PRIORITY);

        high.start();
        low.start();
        System.out.println("High thread alive? " + high.isAlive());
        System.out.println("Low thread alive? " + low.isAlive());
        high.join();
        low.join();

        Thread daemon = new Thread(() -> {
            try {
                Thread.sleep(1000);
                System.out.println("Daemon task finished");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        daemon.setDaemon(true); // Must be set before start().
        daemon.start();
        System.out.println("Main completed; daemon may be stopped when JVM exits.");
    }

    private static void work(String label) {
        for (int i = 1; i <= 5; i++)
            System.out.println(label + " thread step " + i);
    }
}
