class ScannerTask implements Runnable {
    private final int station, scripts;
    ScannerTask(int station, int scripts) {
        this.station = station; this.scripts = scripts;
    }
    public void run() {
        try {
            for (int i = 0; i < scripts; i++) Thread.sleep(10);
            System.out.println("Station " + station + " scanned " + scripts);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
public class RunnableStations {
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = new Thread[4];
        for (int i = 0; i < 4; i++) {
            stations[i] = new Thread(new ScannerTask(i + 1, 5));
            stations[i].start();
        }
        for (Thread t : stations) t.join();
        System.out.println("All stations completed.");
    }
}
