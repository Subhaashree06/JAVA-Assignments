class ScannerStationThread extends Thread {
    private final int station, scripts;
    ScannerStationThread(int station, int scripts) {
        this.station = station; this.scripts = scripts;
    }
    public void run() {
        try {
            for (int i = 0; i < scripts; i++) Thread.sleep(10);
            System.out.println("Station " + station + " scanned " + scripts);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
public class ThreadStations {
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = new Thread[4];
        for (int i = 0; i < 4; i++) {
            stations[i] = new ScannerStationThread(i + 1, 5);
            stations[i].start();
        }
        for (Thread t : stations) t.join();
        System.out.println("All stations completed.");
    }
}
