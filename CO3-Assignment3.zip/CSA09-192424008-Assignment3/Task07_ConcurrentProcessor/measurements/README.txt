Record measured run times for pool sizes 1, 2, 4 and 8 here. Use identical input data for each run.
