import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

class FileResult {
    final String file, studentId, status, message;
    final int total;

    FileResult(String file, String studentId, String status, int total, String message) {
        this.file = file;
        this.studentId = studentId;
        this.status = status;
        this.total = total;
        this.message = message;
    }

    public String toString() {
        return file + " | " + status + " | " + studentId + " | " + total + " | " + message;
    }
}

class ScoreTask implements Callable<FileResult> {
    private final Path path;

    ScoreTask(Path path) { this.path = path; }

    public FileResult call() {
        try {
            List<String> lines = Files.readAllLines(path);
            if (lines.size() < 2)
                throw new IllegalArgumentException("Missing score data");

            String studentId = lines.get(0).trim();
            if (studentId.isEmpty())
                throw new IllegalArgumentException("Missing student ID");

            int total = 0;
            for (int i = 1; i < lines.size(); i++) {
                int mark = Integer.parseInt(lines.get(i).trim());
                if (mark < 0 || mark > 100)
                    throw new IllegalArgumentException("Score outside 0..100");
                total += mark;
            }
            return new FileResult(path.getFileName().toString(),
                    studentId, "SUCCESS", total, "validated");
        } catch (IOException | RuntimeException e) {
            return new FileResult(path.getFileName().toString(),
                    "-", "FAILURE", 0, e.getMessage());
        }
    }
}

public class ConcurrentResultProcessor {
    static void run(Path folder, int poolSize) throws Exception {
        Path manifest = folder.resolve("manifest.txt");
        List<String> names = Files.readAllLines(manifest);
        List<Path> expectedFiles = new ArrayList<>();
        for (String name : names) {
            String trimmed = name.trim();
            if (!trimmed.isEmpty()) expectedFiles.add(folder.resolve(trimmed));
        }

        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        ConcurrentLinkedQueue<FileResult> results = new ConcurrentLinkedQueue<>();
        List<Future<FileResult>> futures = new ArrayList<>();
        long start = System.nanoTime();

        try {
            for (Path file : expectedFiles)
                futures.add(pool.submit(new ScoreTask(file)));

            for (Future<FileResult> future : futures) {
                try {
                    results.add(future.get());
                } catch (ExecutionException e) {
                    results.add(new FileResult("unknown", "-", "FAILURE",
                            0, String.valueOf(e.getCause())));
                }
            }
        } finally {
            pool.shutdown();
            if (!pool.awaitTermination(1, TimeUnit.MINUTES))
                pool.shutdownNow();
        }

        long elapsed = System.nanoTime() - start;
        long success = results.stream().filter(r -> r.status.equals("SUCCESS")).count();
        long failure = results.size() - success;

        System.out.println("Files expected: " + expectedFiles.size());
        System.out.println("Success: " + success);
        System.out.println("Failure: " + failure);
        System.out.println("Total outcomes: " + results.size());
        System.out.printf("Elapsed: %.3f ms (pool=%d)%n", elapsed / 1e6, poolSize);

        if (results.size() != expectedFiles.size())
            throw new IllegalStateException("Incomplete summary");

        Path summary = folder.resolve("summary.txt");
        try (BufferedWriter writer = Files.newBufferedWriter(summary)) {
            for (FileResult result : results)
                writer.write(result + System.lineSeparator());
        }
    }

    public static void main(String[] args) throws Exception {
        Path folder = Paths.get(args.length > 0 ? args[0] : "scores");
        int poolSize = args.length > 1 ? Integer.parseInt(args[1]) : 4;
        if (poolSize < 1) throw new IllegalArgumentException("Pool size must be >= 1");
        run(folder, poolSize);
    }
}
