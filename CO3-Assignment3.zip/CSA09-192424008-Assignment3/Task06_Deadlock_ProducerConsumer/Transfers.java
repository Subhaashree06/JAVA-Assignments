class Wallet {
    final int id;
    int balance;
    Wallet(int id, int balance) { this.id = id; this.balance = balance; }
}
public class Transfers {
    // Safe strategy: every transfer locks wallets in ascending ID order.
    static void transferSafe(Wallet from, Wallet to, int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        Wallet first = from.id < to.id ? from : to;
        Wallet second = from.id < to.id ? to : from;
        synchronized (first) {
            synchronized (second) {
                if (from.balance < amount)
                    throw new IllegalArgumentException("Insufficient balance");
                from.balance -= amount;
                to.balance += amount;
            }
        }
    }

    public static void main(String[] args) {
        Wallet a = new Wallet(1, 1000);
        Wallet b = new Wallet(2, 500);
        transferSafe(a, b, 200);
        System.out.println("Wallet A: " + a.balance);
        System.out.println("Wallet B: " + b.balance);
        System.out.println("Total: " + (a.balance + b.balance));
    }
}
