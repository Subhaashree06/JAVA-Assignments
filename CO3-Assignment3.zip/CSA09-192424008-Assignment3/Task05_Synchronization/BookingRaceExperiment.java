public class BookingRaceExperiment {
    public static void main(String[] args) throws InterruptedException {
        for (int trial = 1; trial <= 10; trial++) {
            SeatBooking screen = new SeatBooking(10);
            Thread[] users = new Thread[100];
            long start = System.nanoTime();

            for (int i = 0; i < users.length; i++) {
                final int seat = i % 10;
                users[i] = new Thread(() -> screen.bookUnsafe(seat));
                users[i].start();
            }
            for (Thread t : users) t.join();

            long elapsed = System.nanoTime() - start;
            System.out.printf("Trial %d: unsafe seats sold=%d, elapsed=%.3f ms%n",
                    trial, screen.getBookingsMade(), elapsed / 1_000_000.0);
        }
    }
}
