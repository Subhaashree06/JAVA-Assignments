public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;

    SeatBooking(int seats) { booked = new boolean[seats]; }

    // Intentionally unsafe version to demonstrate a race condition.
    public boolean bookUnsafe(int seat) {
        if (!booked[seat]) {
            Thread.yield();
            booked[seat] = true;
            bookingsMade++;
            return true;
        }
        return false;
    }

    public synchronized boolean book(int seat) {
        if (booked[seat]) return false;
        booked[seat] = true;
        bookingsMade++;
        return true;
    }

    public boolean bookWithBlock(int seat) {
        synchronized (this) {
            if (booked[seat]) return false;
            booked[seat] = true;
            bookingsMade++;
            return true;
        }
    }

    public int getBookingsMade() { return bookingsMade; }

    public static void main(String[] args) throws InterruptedException {
        runTrial("Synchronized method", 1);
        runTrial("Synchronized block", 2);
    }

    private static void runTrial(String label, int mode) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10);
        Thread[] users = new Thread[100];
        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;
            users[i] = new Thread(() -> {
                if (mode == 1) screen.book(seat);
                else screen.bookWithBlock(seat);
            });
            users[i].start();
        }
        for (Thread t : users) t.join();
        System.out.println(label + " – seats sold: " + screen.getBookingsMade());
    }
}
