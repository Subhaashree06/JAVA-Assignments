import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

class InsufficientFundsException extends Exception {
    InsufficientFundsException(String message) { super(message); }
}
class AccountNotFoundException extends Exception {
    AccountNotFoundException(String message) { super(message); }
}

public class ATMSimulation {
    private static final Map<Integer, Double> accounts = new HashMap<>();
    static {
        accounts.put(1001, 5000.0);
        accounts.put(1002, 1200.0);
    }

    static void withdraw(int account, double amount)
            throws AccountNotFoundException, InsufficientFundsException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        Double balance = accounts.get(account);
        if (balance == null) throw new AccountNotFoundException("Account not found");
        if (amount > balance)
            throw new InsufficientFundsException("Insufficient account balance");
        accounts.put(account, balance - amount);
        System.out.println("Please collect cash: Rs." + amount);
        System.out.println("Remaining balance: Rs." + accounts.get(account));
    }

    public static void main(String[] args) {
        System.out.println("ATM session started");
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter account number (1001 or 1002): ");
            int account = sc.nextInt();
            System.out.print("Enter withdrawal amount: ");
            double amount = sc.nextDouble();

            try {
                withdraw(account, amount);
            } catch (AccountNotFoundException | InsufficientFundsException e) {
                System.out.println("Transaction declined: " + e.getMessage());
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input: enter numeric values only.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid withdrawal: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("ATM service error: " + e.getMessage());
        } finally {
            System.out.println("ATM session closed. Please take your card.");
        }
    }
}
