# Java Assignment 3 – CO3

Repository: `CSA09-192424008-Assignment3`

This repository contains Java source files and sample input files for all seven Assignment 3 tasks.

## Requirements
- JDK 17 or later recommended.
- Open a terminal in the relevant task folder.
- Compile the source file with `javac`.
- Run the class with `java`.

## Folder structure

- `Task01_ATM` – ATM exception handling and custom checked exceptions.
- `Task02_Exceptions` – user-defined exceptions, exception propagation and cause chaining.
- `Task03_Resources` – manual cleanup and try-with-resources report generation.
- `Task04_Threads` – Thread, Runnable, priorities, daemon and lifecycle experiments.
- `Task05_Synchronization` – unsafe race condition and synchronized booking.
- `Task06_Deadlock_ProducerConsumer` – safe wallet transfers and bounded producer-consumer buffer.
- `Task07_ConcurrentProcessor` – ExecutorService, Callable, Future and manifest-based processing.

## Compile and run

Run commands from inside each task folder.

### Task 1 – ATM
```bash
javac ATMSimulation.java
java ATMSimulation
```
Sample valid account numbers: `1001` (balance Rs. 5000) and `1002` (balance Rs. 1200).

### Task 2 – Exception propagation
```bash
javac StorageDemo.java
java StorageDemo
```
The second sample submission is intentionally larger than 500 KB to demonstrate exception chaining.

### Task 3 – Resource handling
```bash
javac ManualSalesReport.java SafeSalesReport.java
java ManualSalesReport
java SafeSalesReport
```
Both programs read `test-files/store1.txt` and `test-files/store2.txt` relative to the current task folder.

### Task 4 – Threads
```bash
javac ThreadStations.java RunnableStations.java ThreadExperiments.java
java ThreadStations
java RunnableStations
java ThreadExperiments
```
Thread completion order can differ between runs. Priority is only a scheduling hint.

### Task 5 – Seat booking
```bash
javac SeatBooking.java BookingRaceExperiment.java
java SeatBooking
java BookingRaceExperiment
```
The unsafe experiment is timing-dependent. Synchronized booking should never sell more than ten unique seats.

### Task 6 – Deadlock and producer-consumer
```bash
javac Transfers.java TokenCounter.java
java Transfers
java TokenCounter
```
The wallet example uses a consistent lock order. The token counter uses a bounded buffer of capacity five.

### Task 7 – Concurrent result processor
Run from inside `Task07_ConcurrentProcessor`:
```bash
javac ConcurrentResultProcessor.java
java ConcurrentResultProcessor . 4
```
The program reads expected filenames from `manifest.txt`. A missing or malformed file is recorded as a failure without stopping the remaining tasks.

Run pool-size experiments:
```bash
java ConcurrentResultProcessor . 1
java ConcurrentResultProcessor . 2
java ConcurrentResultProcessor . 4
java ConcurrentResultProcessor . 8
```
Record actual elapsed times in `measurements/`. Do not invent timing values.

## Important notes
- `Task07_ConcurrentProcessor/scores/S005_missing.txt` is intentionally absent. It appears in the manifest so the processor can demonstrate missing-file handling.
- Generated summary files and console output screenshots are not pre-filled. Run the programs and add your own outputs to the `outputs/` or `measurements/` folders.
- The programs are educational demonstrations and are not production banking, examination, cinema, or clinical systems.
