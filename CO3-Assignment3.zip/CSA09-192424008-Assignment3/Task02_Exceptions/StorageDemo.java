import java.io.IOException;

class ExamException extends Exception {
    ExamException(String message) { super(message); }
    ExamException(String message, Throwable cause) { super(message, cause); }
}
class ExamWindowClosedException extends ExamException {
    ExamWindowClosedException(String message) { super(message); }
}
class StudentNotRegisteredException extends ExamException {
    StudentNotRegisteredException(String message) { super(message); }
}
class SubmissionStorageException extends ExamException {
    SubmissionStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
class InvalidSubmissionRequestException extends RuntimeException {
    InvalidSubmissionRequestException(String message) { super(message); }
}

class Storage {
    void save(String fileName, long sizeKb) throws SubmissionStorageException {
        try {
            if (sizeKb > 500) throw new IOException("Disk quota exceeded");
            System.out.println("Saved " + fileName);
        } catch (IOException e) {
            throw new SubmissionStorageException("Could not store " + fileName, e);
        }
    }
}
class ExamService {
    private final Storage storage = new Storage();

    void submit(String studentId, boolean registered, boolean examOpen,
                String fileName, long sizeKb) throws ExamException {
        if (studentId == null || studentId.trim().isEmpty())
            throw new InvalidSubmissionRequestException("Student ID is required");
        if (!examOpen) throw new ExamWindowClosedException("Exam window is closed");
        if (!registered)
            throw new StudentNotRegisteredException("Student is not registered");
        storage.save(fileName, sizeKb);
    }
}
public class StorageDemo {
    public static void main(String[] args) {
        ExamService service = new ExamService();
        try {
            service.submit("STU001", true, true, "answer01.pdf", 120);
            service.submit("STU002", true, true, "answer02.pdf", 800);
        } catch (ExamException e) {
            System.out.println("Portal message: " + e.getMessage());
            if (e.getCause() != null)
                System.out.println("Original cause: " + e.getCause().getMessage());
            e.printStackTrace();
        } catch (InvalidSubmissionRequestException e) {
            System.out.println("Invalid request: " + e.getMessage());
        }
    }
}
