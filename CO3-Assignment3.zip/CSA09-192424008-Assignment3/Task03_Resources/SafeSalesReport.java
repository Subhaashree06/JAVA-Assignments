import java.io.*;

public class SafeSalesReport {
    public static void generate(String[] files, String output) {
        long total = 0;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(output))) {
            for (String file : files) {
                System.out.println("Processing: " + file);
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null)
                        total += Long.parseLong(line.trim());
                } catch (IOException | NumberFormatException e) {
                    throw new RuntimeException("Could not process " + file, e);
                }
            }
            writer.write("TOTAL=" + total);
        } catch (IOException | RuntimeException e) {
            System.err.println("Report failed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        String[] files = args.length > 0 ? args :
            new String[]{"test-files/store1.txt", "test-files/store2.txt"};
        generate(files, "safe-summary.txt");
        System.out.println("Safe report attempt finished.");
    }
}
