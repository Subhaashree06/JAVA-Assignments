import java.io.*;

public class ManualSalesReport {
    public static void generate(String[] files, String output) {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(output));
            long total = 0;
            for (String file : files) {
                BufferedReader reader = null;
                try {
                    reader = new BufferedReader(new FileReader(file));
                    String line;
                    while ((line = reader.readLine()) != null)
                        total += Long.parseLong(line.trim());
                } catch (IOException | NumberFormatException e) {
                    System.err.println("Failed file " + file + ": " + e.getMessage());
                    throw new RuntimeException("Report incomplete", e);
                } finally {
                    if (reader != null) {
                        try { reader.close(); }
                        catch (IOException closeError) {
                            System.err.println("Close failed: " + closeError.getMessage());
                        }
                    }
                }
            }
            writer.write("TOTAL=" + total);
        } catch (IOException | RuntimeException e) {
            System.err.println("Report generation failed: " + e.getMessage());
        } finally {
            if (writer != null) {
                try { writer.close(); }
                catch (IOException e) {
                    System.err.println("Output close failed: " + e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
        String[] files = args.length > 0 ? args :
            new String[]{"test-files/store1.txt", "test-files/store2.txt"};
        generate(files, "manual-summary.txt");
        System.out.println("Manual report attempt finished.");
    }
}
